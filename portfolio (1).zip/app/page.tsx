import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Github, Linkedin, Mail, ExternalLink, Globe, Gamepad2, ShoppingCart, Phone } from "lucide-react"
import Image from "next/image"

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center justify-between">
            <div className="text-xl font-bold text-foreground">YoYo's Portfolio</div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
                About
              </a>
              <a href="#skills" className="text-muted-foreground hover:text-foreground transition-colors">
                Skills
              </a>
              <a href="#projects" className="text-muted-foreground hover:text-foreground transition-colors">
                Projects
              </a>
              <a href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">
                Contact
              </a>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">Frontend Developer</h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed text-pretty">
                Passionate about creating beautiful, responsive web experiences. Currently learning HTML, CSS, and
                JavaScript to build amazing user interfaces and interactive applications.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  <a href="#projects">View My Projects</a>
                </Button>
                <Button variant="outline" size="lg">
                  <a href="#contact">Get In Touch</a>
                </Button>
              </div>
            </div>
            <div className="flex-shrink-0">
              <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-primary/20 shadow-xl">
                <Image src="/profile-photo.png" alt="Profile photo" fill className="object-cover" priority />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">About Me</h2>
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-lg text-muted-foreground leading-relaxed mb-6 text-pretty">
              I'm a passionate frontend developer on an exciting journey of learning and growth. Every day, I dive
              deeper into the world of web development, exploring HTML, CSS, and JavaScript to create engaging digital
              experiences.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
              My goal is to combine creativity with technical skills to build websites that not only look great but also
              provide exceptional user experiences. From cultural heritage sites to interactive gaming portals and
              modern e-commerce platforms, I enjoy creating diverse web applications.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Skills & Technologies</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">HTML</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">HTML5</h3>
                <p className="text-muted-foreground">
                  Building semantic and accessible web structures with modern HTML5 features
                </p>
              </CardContent>
            </Card>
            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">CSS</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">CSS3</h3>
                <p className="text-muted-foreground">
                  Creating beautiful, responsive designs with advanced CSS3 animations and layouts
                </p>
              </CardContent>
            </Card>
            <Card className="text-center p-6">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">JS</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">JavaScript</h3>
                <p className="text-muted-foreground">
                  Adding interactivity and dynamic functionality with modern JavaScript
                </p>
              </CardContent>
            </Card>
          </div>
          <div className="flex flex-wrap justify-center gap-3 mt-12">
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Responsive Design
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Web Accessibility
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Interactive Games
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              E-commerce UI
            </Badge>
            <Badge variant="secondary" className="text-sm py-2 px-4">
              Cultural Heritage Sites
            </Badge>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">My Projects</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Pharaonic Civilization Project */}
            <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6">
                <div className="w-full h-48 bg-gradient-to-br from-amber-100 to-blue-100 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                  <Globe className="w-16 h-16 text-amber-600" />
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-blue-500/20"></div>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-balance">Pharaonic Civilization</h3>
                <p className="text-muted-foreground mb-4 text-pretty">
                  A comprehensive Arabic website exploring ancient Egyptian history, featuring interactive timelines,
                  pyramid details, and cultural artifacts with beautiful Egyptian-themed styling.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline">HTML5</Badge>
                  <Badge variant="outline">CSS3</Badge>
                  <Badge variant="outline">JavaScript</Badge>
                  <Badge variant="outline">Arabic RTL</Badge>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                  <Button size="sm" className="flex-1">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Live Demo
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* GameHub Project */}
            <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6">
                <div className="w-full h-48 bg-gradient-to-br from-purple-100 to-cyan-100 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                  <Gamepad2 className="w-16 h-16 text-purple-600" />
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-cyan-500/20"></div>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-balance">GameHub Portal</h3>
                <p className="text-muted-foreground mb-4 text-pretty">
                  An interactive gaming portal featuring multiple browser games including Snake, Space Shooter, Memory
                  Match, and Platform Jumper with leaderboards and achievements.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline">HTML5 Canvas</Badge>
                  <Badge variant="outline">JavaScript</Badge>
                  <Badge variant="outline">CSS Animations</Badge>
                  <Badge variant="outline">Game Logic</Badge>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                  <Button size="sm" className="flex-1">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Play Games
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* TechSphere E-commerce Project */}
            <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-6">
                <div className="w-full h-48 bg-gradient-to-br from-blue-100 to-green-100 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                  <ShoppingCart className="w-16 h-16 text-blue-600" />
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-green-500/20"></div>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-balance">TechSphere Store</h3>
                <p className="text-muted-foreground mb-4 text-pretty">
                  A complete e-commerce website for electronics featuring product catalog, shopping cart, quick view
                  modals, checkout process, and responsive design with modern UI.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline">Tailwind CSS</Badge>
                  <Badge variant="outline">JavaScript</Badge>
                  <Badge variant="outline">E-commerce</Badge>
                  <Badge variant="outline">Responsive</Badge>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                  <Button size="sm" className="flex-1">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Shop Demo
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Project Highlights */}
          <div className="mt-16 text-center">
            <h3 className="text-2xl font-semibold mb-6 text-foreground">Project Highlights</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Globe className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-semibold mb-2">Cultural Heritage</h4>
                <p className="text-sm text-muted-foreground">Preserving history through interactive web experiences</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Gamepad2 className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-semibold mb-2">Interactive Gaming</h4>
                <p className="text-sm text-muted-foreground">Building engaging browser games with HTML5 Canvas</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ShoppingCart className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-semibold mb-2">E-commerce Solutions</h4>
                <p className="text-sm text-muted-foreground">
                  Creating modern shopping experiences with dynamic functionality
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-foreground">Get In Touch</h2>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
              I'm always excited to connect with fellow developers, potential collaborators, or anyone interested in web
              development. Let's build something amazing together!
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button size="lg" variant="outline" className="flex items-center gap-2 bg-transparent">
              <Phone className="w-5 h-5" />
              <a href="tel:01212872972">01212872972</a>
            </Button>
            <Button size="lg" variant="outline" className="flex items-center gap-2 bg-transparent">
              <Mail className="w-5 h-5" />
              Send Email
            </Button>
            <Button size="lg" variant="outline" className="flex items-center gap-2 bg-transparent">
              <Github className="w-5 h-5" />
              GitHub Profile
            </Button>
            <Button size="lg" variant="outline" className="flex items-center gap-2 bg-transparent">
              <Linkedin className="w-5 h-5" />
              LinkedIn
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30 py-8 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <p className="text-muted-foreground">
            © 2024 YoYo's Portfolio. Built with passion and dedication to learning frontend development.
          </p>
        </div>
      </footer>
    </div>
  )
}
